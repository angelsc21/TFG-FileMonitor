Aplicación Android que utiliza FileObserver para capturar los eventos que se producen en el sistema de archivos de la memoria externa.

App desarrollada durante el estudio de Detección de Malware en Android, como Trabajo de Fin de Máster por Jesús Rodríguez Pérez.
